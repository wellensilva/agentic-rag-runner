# Kit Runner — Agentic RAG (N2–N3)

Runner mínimo para varrer o arXiv sobre **Agentic RAG**, com política **N2–N3**, **Termômetro+** implícito (seguro) e **pipeline** `retrieve → rerank → extract → cite`, gerando **logs JSONL**.

## ☑️ Requisitos
- Python 3.10+
- `pip install requests pyyaml feedparser`

## ▶️ Executar localmente
```bash
python runner.py --task agentic_rag
```
Parâmetros úteis:
```bash
python runner.py --task agentic_rag --query "agentic RAG" --max_results 3 --days_back 365
```

## 🧰 Política (policy.yaml)
- Limites: `steps_max=5`, `timebox_min=20`
- Segurança: `require_sources`, `fail_closed`, `kill_switch`
- Memória: por padrão **não escreve** durável (`durable_write:false`)
- Logging: JSONL em `logs/`

## ⏰ GitHub Actions (agendamento semanal)
Crie o repositório e adicione este workflow:

`.github/workflows/agentic-rag.yml`
```yaml
name: agentic-rag
on:
  schedule:
    - cron: "0 12 * * 1"  # segundas 12:00 UTC
  workflow_dispatch:
jobs:
  run:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install requests pyyaml feedparser
      - run: python runner.py --task agentic_rag --max_results 3
      - name: Salvar logs como artifact
        uses: actions/upload-artifact@v4
        with:
          name: logs
          path: logs/
```

## ☁️ Replit (sem servidor)
1. Crie um Repl (Python).
2. Suba estes arquivos (`policy.yaml`, `runner.py`, `README.md`).
3. Em *Packages*, instale `requests`, `pyyaml`, `feedparser`.
4. Rode: `python runner.py --task agentic_rag --max_results 3`  
   (Para agendar, use o *Always On* + cron do Replit ou um serviço externo de pings.)

## 🧪 Saída
- `stdout`: um JSON com `results` (id, title, bullets).
- `logs/run-YYYYMMDD-HHMM.jsonl`: LOG por etapa.

## 🛑 Kill-switch
Defina a variável de ambiente `KILL_SWITCH="PAUSAR AGORA"` para interromper.

## 🔒 Memória durável (opcional)
Se decidir ativar, edite `policy.yaml`:
```yaml
memory:
  durable_write: true
  ttl_required: true
  storage_path: "memory.json"
```
> **Recomendado** manter `false` até precisar mesmo guardar.

---
Feito com carinho para sua rotina **N2–N3** 💫
