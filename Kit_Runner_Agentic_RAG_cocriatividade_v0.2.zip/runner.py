#!/usr/bin/env python3
# runner.py — Runner mínimo para Agentic RAG (N2–N3)
# Requisitos: pip install requests pyyaml feedparser
import os, sys, time, json, argparse, datetime, re
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
import yaml, requests, feedparser

# ------------------------ Utilidades ------------------------
def now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z"

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def save_jsonl(path: str, rows: List[Dict[str, Any]]):
    with open(path, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def sanitize_text(t: str) -> str:
    return re.sub(r"\s+", " ", (t or "")).strip()

# ------------------------ Termômetro+ ------------------------
@dataclass
class ThermometerScore:
    R:int; I:int; C:int; F:int; M:int; K:int
    def total(self): return self.R+self.I+self.C+self.F+self.M+self.K

def decide_level(score: ThermometerScore, thresholds: Dict[str,int]) -> str:
    total = score.total()
    if total <= thresholds.get("N1_max",7):
        return "N1"
    elif total <= thresholds.get("N2_max",13):
        return "N2"
    else:
        return "N3"

# ------------------------ Memória durável ------------------------
def read_memory(path: str) -> List[Dict[str,Any]]:
    if not os.path.exists(path): return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def write_memory(path: str, data: List[Dict[str,Any]]):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def ttl_expired(item: Dict[str,Any]) -> bool:
    ttl = item.get("ttl_days")
    created = item.get("created_at")
    if not ttl or not created: return False
    try:
        created_dt = datetime.datetime.fromisoformat(created.replace("Z",""))
        return (datetime.datetime.utcnow() - created_dt).days > int(ttl)
    except Exception:
        return False

# ------------------------ ArXiv (retrieve) ------------------------
def arxiv_search(query: str, max_results: int = 5, days_back: int = 365) -> List[Dict[str,Any]]:
    base = "http://export.arxiv.org/api/query"
    # Tempo (days_back) é ilustrativo — arXiv API não filtra por data diretamente via parâmetro simples;
    # usamos o query geral e depois filtramos pelo updated_parsed.
    url = f"{base}?search_query=all:{requests.utils.quote(query)}&start=0&max_results={max_results*3}&sortBy=submittedDate&sortOrder=descending"
    feed = feedparser.parse(url)
    items = []
    cutoff = datetime.datetime.utcnow() - datetime.timedelta(days=days_back)
    for e in feed.entries:
        updated = getattr(e, "updated_parsed", None) or getattr(e, "published_parsed", None)
        dt = datetime.datetime(*updated[:6]) if updated else None
        if dt and dt >= cutoff:
            items.append({
                "id": e.get("id"),
                "title": sanitize_text(e.get("title")),
                "summary": sanitize_text(e.get("summary")),
                "authors": [a.name for a in e.get("authors", [])] if hasattr(e, "authors") else [],
                "updated": dt.isoformat()+"Z"
            })
        if len(items) >= max_results*2:
            break
    return items[:max_results*2]

# ------------------------ Rerank (muito simples) ------------------------
def keyword_score(text: str, keywords: List[str]) -> int:
    text_low = (text or "").lower()
    return sum(text_low.count(k.lower()) for k in keywords)

def rerank(items: List[Dict[str,Any]], keywords: List[str], top_k:int=3) -> List[Dict[str,Any]]:
    scored = []
    for it in items:
        score = keyword_score(it["title"]+" "+it["summary"], keywords)
        scored.append((score, it))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [it for (s,it) in scored[:top_k]]

# ------------------------ Extract (5 bullets heurísticos) ------------------------
def extract_bullets(summary: str, max_bullets:int=5) -> List[str]:
    # Heurística simples: pegar frases e limitar tamanho
    sentences = re.split(r'(?<=[.!?])\s+', summary)
    bullets = []
    for s in sentences:
        s = sanitize_text(s)
        if len(s) < 15: 
            continue
        bullets.append(s[:280])
        if len(bullets) >= max_bullets:
            break
    if not bullets and summary:
        bullets = [summary[:280]]
    return bullets

# ------------------------ Cite ------------------------
def cite_id(url: str) -> str:
    # Retorna o ID arXiv curto quando possível
    # Exemplos: http://arxiv.org/abs/2501.01234v1
    m = re.search(r'arxiv\.org\/abs\/([\d\.v]+)', url or "")
    return m.group(1) if m else url

# ------------------------ Runner ------------------------
def run_agentic_rag(policy: Dict[str,Any], args) -> Dict[str,Any]:
    log_dir = policy["logging"]["dir"]
    ensure_dir(log_dir)
    run_id = datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    log_path = os.path.join(log_dir, f"{policy['logging']['file_prefix']}-{run_id}.jsonl")

    # 0) Termômetro (auto)
    score = ThermometerScore(R=3,I=3,C=3,F=2,M=3,K=3) # por padrão seguro
    level = decide_level(score, policy.get("thermometer_thresholds",{}))

    plan = {
        "objective": "Mapear trabalhos arXiv sobre Agentic RAG com foco em memória e cadeia/orquestração",
        "sources": "arXiv (últimos 12 meses, sort=submittedDate)",
        "steps": ["retrieve","rerank","extract","cite"],
        "success": "3 artigos + 5 bullets cada + citações",
        "limits": policy.get("limits", {}),
        "level_suggested": level,
        "score": asdict(score),
        "started_at": now_iso()
    }
    save_jsonl(log_path, [{"ts": now_iso(), "event":"plan", "data": plan}])

    # 1) Retrieve
    q = args.query or policy["search"]["query"]
    max_results = int(args.max_results or policy["search"]["max_results"])
    days_back = int(args.days_back or policy["search"]["days_back"])
    items = arxiv_search(q, max_results=max_results, days_back=days_back)
    save_jsonl(log_path, [{"ts": now_iso(), "event":"retrieve", "data": {"count": len(items), "query": q}}])

    # 2) Rerank
    kw = ["agentic", "RAG", "memory", "tool", "multi-agent", "retrieval", "planning", "reflection"]
    top = rerank(items, kw, top_k=max_results)
    save_jsonl(log_path, [{"ts": now_iso(), "event":"rerank", "data": {"kept": len(top), "keywords": kw}}])

    # 3) Extract
    results = []
    for it in top:
        bullets = extract_bullets(it["summary"], max_bullets=5)
        results.append({
            "id": cite_id(it["id"]),
            "title": it["title"],
            "updated": it["updated"],
            "bullets": bullets
        })
    save_jsonl(log_path, [{"ts": now_iso(), "event":"extract", "data": {"count": len(results)}}])

    # 4) Cite
    # (Já incluímos id/links nos resultados)
    save_jsonl(log_path, [{"ts": now_iso(), "event":"cite", "data": {"ids": [r['id'] for r in results]}}])

    # Reflexão simples
    reflection = {
        "gap": "Validação em produção limitada nas amostras; recomenda-se testes incrementais.",
        "next_step": "Adicionar métrica simples de cobertura (nº de fontes únicas) e registrar redundância."
    }
    save_jsonl(log_path, [{"ts": now_iso(), "event":"reflection", "data": reflection}])

    deliverable = {
        "run_id": run_id,
        "level": level,
        "score": asdict(score),
        "results": results,
        "reflection": reflection,
        "log_path": log_path
    }
    return deliverable

# ------------------------ CLI ------------------------
def main():
    parser = argparse.ArgumentParser(description="Runner mínimo Agentic RAG (N2–N3)")
    parser.add_argument("--policy", default="policy.yaml")
    parser.add_argument("--task", default="agentic_rag")
    parser.add_argument("--query", default=None, help="override da query (ex.: \"agentic RAG\")")
    parser.add_argument("--max_results", default=None)
    parser.add_argument("--days_back", default=None)
    args = parser.parse_args()

    # Kill-switch por env var
    if os.environ.get("KILL_SWITCH","").strip().upper() == "PAUSAR AGORA":
        print("Kill-switch acionado. Saindo.")
        sys.exit(1)

    with open(args.policy, "r", encoding="utf-8") as f:
        policy = yaml.safe_load(f)

    if args.task == "agentic_rag":
        out = run_agentic_rag(policy, args)
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        print("Tarefa desconhecida. Use --task agentic_rag")

if __name__ == "__main__":
    main()
